package pizzaCalories_04;

public class Topping {
    private String toppingType;
    private double weigh;

    public Topping(String toppingType, double weigh) {
        this.setToppingType(toppingType);
        this.setWeigh(weigh);
    }

    private void setToppingType(String toppingType) {
        switch (toppingType) {
            case "Meat":
            case "Veggies":
            case "Cheese":
            case "Sauce":
                this.toppingType = toppingType;
                break;
            default:
                throw new IllegalArgumentException(String.format("Cannot place %s on top of your pizza.", toppingType));
        }
    }

    private void setWeigh(double weigh) {
        if (weigh < 1 || weigh > 50) {
            throw new IllegalArgumentException(String.format("%s weight should be in the range [1..50].", toppingType));
        }
            this.weigh = weigh;
    }

    public double calculateCalories() {
        double toppingCalories = 0.0;

        switch (toppingType) {
            case "Meat":
                toppingCalories = 1.2;
                break;
            case "Veggies":
                toppingCalories = 0.8;
                break;
            case "Cheese":
                toppingCalories = 1.1;
                break;
            case "Sauce":
                toppingCalories = 0.9;
                break;
        }
        return (2 * weigh) * toppingCalories;
    }
}
