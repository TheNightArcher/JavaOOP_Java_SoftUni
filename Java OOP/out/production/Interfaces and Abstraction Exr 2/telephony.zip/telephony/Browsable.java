package telephony;

import java.util.regex.Matcher;

public interface Browsable {
    String browse();
}
