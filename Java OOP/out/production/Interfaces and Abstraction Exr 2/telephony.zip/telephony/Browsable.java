package telephony;


public interface Browsable {

    String browse();
}